---
name: Task
about: Describe a generic activity we should carry out.
---


### What should we do?

<!-- Clearly describe the activity we should carry out. -->


### Why should we do it?

<!-- Argue why doing it is a healthy investment of our time. -->
