import debounceInput from './debounceInput';

export default {
  debounceInput: [ 'factory', debounceInput ]
};