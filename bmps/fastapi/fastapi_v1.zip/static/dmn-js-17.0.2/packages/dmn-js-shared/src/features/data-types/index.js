import DataTypes from './DataTypes';

export default {
  __init__: [ 'dataTypes' ],
  dataTypes: [ 'type', DataTypes ]
};