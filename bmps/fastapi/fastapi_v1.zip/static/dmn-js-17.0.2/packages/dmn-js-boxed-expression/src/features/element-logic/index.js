import ElementLogic from './ElementLogic';

export default {
  __init__: [ 'elementLogic' ],
  elementLogic: [ 'type', ElementLogic ],
};
