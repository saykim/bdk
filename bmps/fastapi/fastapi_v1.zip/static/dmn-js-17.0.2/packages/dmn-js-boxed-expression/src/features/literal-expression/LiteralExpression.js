export default class LiteralExpression {
  getText(literalExpression) {
    return literalExpression.get('text');
  }
}
