import ElementProperties from './ElementProperties';

export default {
  __init__: [ 'elementProperties' ],
  elementProperties: [ 'type', ElementProperties ]
};