import ColumnResizeProvider from './ColumnResizeProvider';

export default {
  __init__: [
    'columnResizeProvider'
  ],
  columnResizeProvider: [ 'type', ColumnResizeProvider ]
};