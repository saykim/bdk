import importModule from '../import';
import renderModule from 'table-js/lib/render';

export default {
  __depends__: [
    importModule,
    renderModule
  ]
};