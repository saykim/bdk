import DecisionTableHeadProvider from './DecisionTableHeadProvider';

export default {
  __init__: [ 'decisionTableHeadProvider' ],
  decisionTableHeadProvider: [ 'type', DecisionTableHeadProvider ]
};