import LiteralExpressionProperties from './LiteralExpressionProperties';

export default {
  __depends__: [
  ],
  __init__: [ 'literalExpressionProperties' ],
  literalExpressionProperties: [ 'type', LiteralExpressionProperties ]
};