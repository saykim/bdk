'use strict';

var createConfig = require('dmn-js-shared/karma.base');

var path = require('path');

module.exports = createConfig(path.resolve(__dirname));