import EditorActions from './EditorActions';

export default {
  __init__: [ 'editorActions' ],
  editorActions: [ 'type', EditorActions ]
};