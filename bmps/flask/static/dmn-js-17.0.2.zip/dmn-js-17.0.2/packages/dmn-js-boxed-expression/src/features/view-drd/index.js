import ViewDrd from './ViewDrd';

export default {
  __init__: [ 'viewDrd' ],
  viewDrd: [ 'type', ViewDrd ]
};