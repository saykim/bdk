import ElementRegistry from './ElementRegistry';

export default {
  __init__: [ 'elementRegistry' ],
  elementRegistry: [ 'type', ElementRegistry ]
};