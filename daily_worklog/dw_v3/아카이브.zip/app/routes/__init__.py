# routes 패키지 초기화
from app.routes.auth import bp as auth_bp
from app.routes.worklog import bp as worklog_bp 