from flask import Blueprint, render_template, request, jsonify
from app.models import ProductionPlan
from app import db
from datetime import datetime

main = Blueprint('main', __name__)

@main.route('/')
def index():
    return render_template('index.html')

@main.route('/api/plans', methods=['GET'])
def get_plans():
    plans = ProductionPlan.query.all()
    return jsonify([plan.to_dict() for plan in plans])

@main.route('/api/plans', methods=['POST'])
def create_plan():
    data = request.json
    try:
        start_time = datetime.fromisoformat(data['start_time'])
        plan = ProductionPlan(
            factory=data['factory'],
            product=data['product'],
            order_number=data['order_number'],
            start_time=start_time,
            duration_hours=float(data['duration_hours']),
            quantity=int(data['quantity'])
        )
        db.session.add(plan)
        db.session.commit()
        return jsonify(plan.to_dict()), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 400 