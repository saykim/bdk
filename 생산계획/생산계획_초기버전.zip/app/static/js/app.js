// 메인 애플리케이션 클래스
class ProductionPlanApp {
    constructor() {
        this.ganttManager = new GanttDataManager();
        this.form = document.getElementById('productionForm');
        this.initializeApp();
    }

    // 애플리케이션 초기화
    initializeApp() {
        // 간트 차트 설정 초기화
        initializeGanttConfig();
        
        // 간트 차트 초기화
        gantt.init("gantt_here");
        
        // 이벤트 리스너 등록
        this.registerEventListeners();
        
        // 초기 데이터 로드
        this.loadInitialData();
    }

    // 이벤트 리스너 등록
    registerEventListeners() {
        this.form.addEventListener('submit', this.handleFormSubmit.bind(this));
    }

    // 폼 제출 처리
    async handleFormSubmit(e) {
        e.preventDefault();
        
        try {
            const formData = this.getFormData();
            this.validateFormData(formData);
            await this.ganttManager.addPlan(formData);
            this.form.reset();
        } catch (error) {
            console.error('생산계획 추가 중 오류:', error);
            alert(error.message || '생산계획 추가 중 오류가 발생했습니다.');
        }
    }

    // 폼 데이터 가져오기
    getFormData() {
        return {
            factory: document.getElementById('factory').value.trim(),
            product: document.getElementById('product').value.trim(),
            order_number: document.getElementById('orderNumber').value.trim(),
            start_time: document.getElementById('startTime').value,
            duration_hours: parseFloat(document.getElementById('duration').value),
            quantity: parseInt(document.getElementById('quantity').value)
        };
    }

    // 폼 데이터 검증
    validateFormData(formData) {
        if (!formData.factory || !formData.product || !formData.order_number) {
            throw new Error('모든 필드를 입력해주세요.');
        }

        if (isNaN(formData.duration_hours) || formData.duration_hours <= 0) {
            throw new Error('올바른 생산 시간을 입력해주세요.');
        }

        if (isNaN(formData.quantity) || formData.quantity <= 0) {
            throw new Error('올바른 수량을 입력해주세요.');
        }
    }

    // 초기 데이터 로드
    async loadInitialData() {
        try {
            await this.ganttManager.loadPlans();
        } catch (error) {
            alert('생산계획을 불러오는 중 오류가 발생했습니다.');
        }
    }
}

// 애플리케이션 시작
document.addEventListener('DOMContentLoaded', () => {
    window.app = new ProductionPlanApp();
}); 