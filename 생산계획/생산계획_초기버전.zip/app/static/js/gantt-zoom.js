// 줌 레벨 설정
const zoomConfig = {
    levels: [
        {
            name: "hour",
            scale_height: 50,
            min_column_width: 30,
            scales: [
                {unit: "hour", step: 1, format: "%H시"},
                {unit: "day", step: 1, format: "%m/%d (%D)"}
            ]
        },
        {
            name: "day",
            scale_height: 50,
            min_column_width: 50,
            scales: [
                {unit: "day", step: 1, format: "%m/%d (%D)"},
                {unit: "week", step: 1, format: "%Y년 %W주"}
            ]
        },
        {
            name: "week",
            scale_height: 50,
            min_column_width: 70,
            scales: [
                {unit: "week", step: 1, format: "%Y년 %W주"},
                {unit: "month", step: 1, format: "%Y년 %M"}
            ]
        }
    ],
    currentLevel: 0
};

// 줌 인
function zoomIn() {
    if (zoomConfig.currentLevel > 0) {
        zoomConfig.currentLevel--;
        applyZoom();
    }
}

// 줌 아웃
function zoomOut() {
    if (zoomConfig.currentLevel < zoomConfig.levels.length - 1) {
        zoomConfig.currentLevel++;
        applyZoom();
    }
}

// 줌 레벨 적용
function applyZoom() {
    const level = zoomConfig.levels[zoomConfig.currentLevel];
    gantt.config.scale_height = level.scale_height;
    gantt.config.min_column_width = level.min_column_width;
    gantt.config.scales = level.scales;
    gantt.render();
} 