// 한국어 로케일 설정
function setGanttLocale() {
    gantt.i18n.setLocale({
        date: {
            month_full: ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"],
            month_short: ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"],
            day_full: ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"],
            day_short: ["일", "월", "화", "수", "목", "금", "토"]
        },
        labels: {
            new_task: "새 작업",
            icon_save: "저장",
            icon_cancel: "취소",
            icon_details: "상세",
            section_description: "설명",
            section_time: "기간",
            confirm_deleting: "작업을 삭제하시겠습니까?",
            section_title: "제목"
        }
    });
}

// 간트 차트 기본 설정
function configureGantt() {
    // 기본 설정
    gantt.config.date_format = "%Y-%m-%d %H:%i";
    gantt.config.scale_height = 50;
    gantt.config.row_height = 30;
    gantt.config.task_height = 16;
    gantt.config.min_column_width = 40;
    gantt.config.duration_unit = "hour";
    gantt.config.duration_step = 1;
    gantt.config.scale_unit = "day";
    gantt.config.fit_tasks = true;
    gantt.config.show_unscheduled = true;
    gantt.config.sort = true;

    // 드래그 앤 드롭 비활성화
    gantt.config.drag_move = false;
    gantt.config.drag_progress = false;
    gantt.config.drag_resize = false;
    gantt.config.drag_links = false;

    // 읽기 전용 설정
    gantt.config.readonly = true;

    // 작업 정렬 설정
    gantt.config.sort = function(a, b) {
        a = gantt.getTask(a);
        b = gantt.getTask(b);
        
        if (a.type === "project" && b.type !== "project") return -1;
        if (a.type !== "project" && b.type === "project") return 1;
        
        return a.start_date.getTime() - b.start_date.getTime();
    };

    // 타임라인 스케일 설정
    gantt.config.scales = [
        {unit: "hour", step: 1, format: "%H시"},
        {unit: "day", step: 1, format: "%m/%d (%D)"}
    ];

    // 열 설정
    gantt.config.columns = [
        {name: "text", label: "작업명", tree: true, width: 200, resize: true},
        {name: "factory", label: "공장", align: "center", width: 80, resize: true},
        {name: "product", label: "제품", align: "center", width: 100, resize: true},
        {name: "order_number", label: "오더번호", align: "center", width: 100, resize: true},
        {name: "quantity", label: "수량", align: "center", width: 70, resize: true, template: function(task) {
            return task.quantity ? task.quantity + "개" : "";
        }},
        {name: "duration", label: "시간", align: "center", width: 70, resize: true, template: function(task) {
            return task.duration ? task.duration + "시간" : "";
        }}
    ];

    // 템플릿 설정
    gantt.templates.task_text = function(start, end, task) {
        if (task.type === "project") return task.text;
        return `${task.text} (${task.quantity}개)`;
    };

    gantt.templates.task_class = function(start, end, task) {
        return task.type === "project" ? "gantt_project" : "gantt_task";
    };

    gantt.templates.tooltip_text = function(start, end, task) {
        if (task.type === "project") return task.text;
        return `<b>${task.text}</b><br>
                공장: ${task.factory}<br>
                제품: ${task.product}<br>
                오더번호: ${task.order_number}<br>
                수량: ${task.quantity}개<br>
                시작: ${gantt.templates.tooltip_date_format(start)}<br>
                시간: ${task.duration}시간`;
    };

    // 내보내기 설정
    gantt.config.export_date_format = "%Y-%m-%d %H:%i";
    gantt.config.export_styles = true;
}

// 설정 초기화 함수
function initializeGanttConfig() {
    setGanttLocale();
    configureGantt();
} 