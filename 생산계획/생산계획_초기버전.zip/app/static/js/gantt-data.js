// 데이터 처리 클래스
class GanttDataManager {
    constructor() {
        this.gantt = gantt;
        this.currentZoomLevel = 0;
        this.zoomLevels = [
            {
                name: "hour",
                scale_height: 50,
                min_column_width: 30,
                scales: [
                    {unit: "hour", step: 1, format: "%H시"},
                    {unit: "day", step: 1, format: "%m/%d (%D)"}
                ]
            },
            {
                name: "day",
                scale_height: 50,
                min_column_width: 50,
                scales: [
                    {unit: "day", step: 1, format: "%m/%d (%D)"},
                    {unit: "week", step: 1, format: "%Y년 %W주"}
                ]
            },
            {
                name: "week",
                scale_height: 50,
                min_column_width: 70,
                scales: [
                    {unit: "week", step: 1, format: "%Y년 %W주"},
                    {unit: "month", step: 1, format: "%Y년 %M"}
                ]
            }
        ];
    }

    // 줌 인
    zoomIn() {
        if (this.currentZoomLevel > 0) {
            this.currentZoomLevel--;
            this.applyZoom();
        }
    }

    // 줌 아웃
    zoomOut() {
        if (this.currentZoomLevel < this.zoomLevels.length - 1) {
            this.currentZoomLevel++;
            this.applyZoom();
        }
    }

    // 줌 레벨 적용
    applyZoom() {
        const level = this.zoomLevels[this.currentZoomLevel];
        this.gantt.config.scale_height = level.scale_height;
        this.gantt.config.min_column_width = level.min_column_width;
        this.gantt.config.scales = level.scales;
        this.gantt.render();
    }

    // PDF 내보내기
    exportToPDF() {
        this.gantt.exportToPDF({
            name: `생산계획_${new Date().toLocaleDateString()}.pdf`,
            header: '<h1>생산계획</h1>',
            raw: true
        });
    }

    // Excel 내보내기
    exportToExcel() {
        this.gantt.exportToExcel({
            name: `생산계획_${new Date().toLocaleDateString()}.xlsx`,
            raw: true
        });
    }

    // 데이터 처리
    processData(plans) {
        if (!plans?.length) return { data: [], links: [] };
        
        const tasks = {
            data: [],
            links: []
        };
        
        const factoryGroups = {};
        
        // 시작 시간과 종료 시간 계산
        let minDate = new Date(plans[0].start_time);
        let maxDate = new Date(plans[0].start_time);
        
        plans.forEach(plan => {
            try {
                const startTime = new Date(plan.start_time);
                const endTime = new Date(startTime.getTime() + (plan.duration_hours * 60 * 60 * 1000));
                
                minDate = startTime < minDate ? startTime : minDate;
                maxDate = endTime > maxDate ? endTime : maxDate;
                
                // 공장 그룹 처리
                if (!factoryGroups[plan.factory]) {
                    const factoryId = `factory_${plan.factory.replace(/[^a-zA-Z0-9]/g, '_')}`;
                    factoryGroups[plan.factory] = {
                        id: factoryId,
                        text: `[공장] ${plan.factory}`,
                        type: "project",
                        render: "split",
                        open: true,
                        start_date: startTime,
                        end_date: endTime,
                        duration: plan.duration_hours,
                        readonly: true
                    };
                    tasks.data.push(factoryGroups[plan.factory]);
                } else {
                    const group = factoryGroups[plan.factory];
                    if (startTime < new Date(group.start_date)) {
                        group.start_date = startTime;
                    }
                    if (endTime > new Date(group.end_date)) {
                        group.end_date = endTime;
                    }
                }
                
                // 작업 추가
                tasks.data.push({
                    id: plan.id.toString(),
                    text: `[오더] ${plan.order_number}`,
                    start_date: startTime,
                    end_date: endTime,
                    duration: plan.duration_hours,
                    parent: factoryGroups[plan.factory].id,
                    factory: plan.factory,
                    product: plan.product,
                    order_number: plan.order_number,
                    quantity: plan.quantity,
                    progress: 0,
                    readonly: true
                });
            } catch (error) {
                console.error('Plan processing error:', error, plan);
            }
        });
        
        // 전체 타임라인 범위 설정
        this.gantt.config.start_date = new Date(minDate.getTime() - 24 * 60 * 60 * 1000);
        this.gantt.config.end_date = new Date(maxDate.getTime() + 24 * 60 * 60 * 1000);
        
        return tasks;
    }

    // 데이터 로드
    async loadPlans() {
        try {
            const response = await fetch('/api/plans');
            if (!response.ok) {
                throw new Error('서버 응답 오류: ' + response.status);
            }
            
            const plans = await response.json();
            if (!plans?.length) {
                this.gantt.clearAll();
                return;
            }
            
            const tasks = this.processData(plans);
            this.gantt.clearAll();
            this.gantt.parse(tasks);
            this.gantt.render();
            
        } catch (error) {
            console.error('생산계획 로드 중 오류 발생:', error);
            throw error;
        }
    }

    // 새 계획 추가
    async addPlan(formData) {
        try {
            const response = await fetch('/api/plans', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.error || '서버 오류가 발생했습니다.');
            }

            await this.loadPlans();
        } catch (error) {
            console.error('Plan addition error:', error);
            throw error;
        }
    }
} 