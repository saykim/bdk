from app import db
from datetime import datetime

class ProductionPlan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    factory = db.Column(db.String(100), nullable=False)
    product = db.Column(db.String(100), nullable=False)
    order_number = db.Column(db.String(100), nullable=False)
    start_time = db.Column(db.DateTime, nullable=False)
    duration_hours = db.Column(db.Float, nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'factory': self.factory,
            'product': self.product,
            'order_number': self.order_number,
            'start_time': self.start_time.isoformat(),
            'duration_hours': self.duration_hours,
            'quantity': self.quantity
        } 